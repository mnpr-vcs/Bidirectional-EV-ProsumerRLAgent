# Battery Usage graph
# 
# x:time, y:soc/energycontent
# 
# ~ 
# |
# |
# |
# |--1.0--------------------------------|
# |    #                                |
# |  ####            #                    |
# |--0.5--#---#----####-----------------|
# | #######  ###  ########   #          |
# | ########################## ____#___ |
#  -0.0------------ 0% ------------------------->
# 6:00    12:00    18:00    00:00    ...  
#               ( timesteps )
# A graph describing the energy usage w.r.t time.
#################################################################


# part of custom_env (constraints on battery and bev)
def battery_care(
        charge_limit=0.9, retain_threshold=0.3, encouraging=False
    ):
    """charging limit and retain threshold constraint on soc."""
    if not encouraging:
        if battery.current_soc > charge_limit:
            soc_reward = -0.1 
        elif battery.current_soc < retain_threshold
            soc_reward = -0.3
        else:
            soc_reward = 0 
    else: # rewarding to stay within a range
        if battery.current_soc > charge_limit 
            and battery.current_soc < retain_threshold: 
            soc_reward = 0.1 
        else:
            soc_reward = 0

    return soc_reward


# weighted rewards 



