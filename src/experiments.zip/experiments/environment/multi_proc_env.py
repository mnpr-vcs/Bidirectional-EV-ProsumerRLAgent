import time
import gymnasium as gym
import matplotlib.pyplot as plt
import numpy as np
from stable_baselines3.common.vec_env import DummyVecEnv, SubprocVecEnv
from stable_baselines3.common.utils import set_random_seed
from stable_baselines3.common.evaluation import evaluate_policy
from stable_baselines3.common.env_util import make_vec_env
from stable_baselines3 import PPO

import hems_env
from components.battery import HEMSBattery
from utils.configs import data_config
from utils.processing import parse_timeseries_data
from utils.event_logger import logger


power_household_o, power_pv_o, soc = parse_timeseries_data(data_config=data_config)

power_household_o = power_household_o
power_pv_o = power_pv_o
initial_soc = soc.iloc[0]
logger.info("dataset loaded")

battery = HEMSBattery(initial_soc=initial_soc, max_capacity=50.0)


ENV_ID = "hems_env/HouseholdEnv-v0"
ENV_KWARGS = {
    "power_household": power_household_o,
    "power_pv": power_pv_o,
    "battery": battery
}

env = gym.make(ENV_ID, **ENV_KWARGS)

PROCESSES_TO_TEST = [1, 2, 4, 8, 16]
NUM_OF_EXPERIMENTS = 5
TRAINING_TIMESTEPS = 10000
EVAL_EPISODES = 10
ALGORITHM = PPO
POLICY = "MlpPolicy"

# evaluation environment -----------------------
eval_env = gym.make(ENV_ID, **ENV_KWARGS)

# def make_env(env_id: str, rank: int, seed: int=0, **env_kwargs):
#     def _init():
#         env = gym.make( env_id, **env_kwargs)
#         env.reset(seed + rank)
#         return env

#     set_random_seed(seed)
#     return _init

def make_env(env: gym.Env, rank: int, seed: int=0):
    def _init():
        env = env
        env.reset(seed + rank)
        return env

    set_random_seed(seed)
    return _init


def main():
    reward_mean = []
    reward_std = []
    training_times = []
    total_processes = 0


    for n_procs in PROCESSES_TO_TEST:
        total_processes += n_procs
        logger.info(f"running process no. : {n_procs}")

        if n_procs == 1: # for single process
            train_env = DummyVecEnv(
                [lambda: gym.make(ENV_ID, **ENV_KWARGS)]
            )
        else:
            # equivalent  ------------------------
            train_env = make_vec_env(
                env_id=ENV_ID,
                env_kwargs=ENV_KWARGS,
                n_envs=n_procs,
                vec_env_cls=SubprocVecEnv,
                vec_env_kwargs=dict(start_method='fork')
            )
            # train_env = SubprocVecEnv(
            #     [
            #         make_env(
            #             env=gym.make(ENV_ID, **ENV_KWARGS), rank=(i+total_processes)
            #         ) for i in range(n_procs)
            #     ],
            #     start_method="fork",
            # )

        rewards = []
        times = []
        for _ in range(NUM_OF_EXPERIMENTS):
            train_env.reset()
            model = ALGORITHM(POLICY, train_env, verbose=0)
            start = time.time()
            model.learn(total_timesteps=TRAINING_TIMESTEPS)
            end = time.time()-start
            logger.info(f"timedelta: {end}")
            times.append(end)
            mean_rewards, _ = evaluate_policy(
                model, eval_env, n_eval_episodes=EVAL_EPISODES
            )
            rewards.append(mean_rewards)
        train_env.close()
        reward_mean.append(np.mean(rewards))
        reward_std.append(np.std(rewards))
        training_times.append(np.mean(times))

    # plot results
    training_steps_ps = [TRAINING_TIMESTEPS/ t for t in training_times]
    plt.figure(figsize=(15, 8))
    plt.subplots_adjust(wspace=0.5)
    plt.subplot(1, 2, 1)
    plt.errorbar(
        PROCESSES_TO_TEST,
        reward_mean,
        yerr=reward_std,
        capsize=2,
        c="k",
        marker="o",
    )
    plt.xlabel("Processes")
    plt.ylabel("Average return")
    plt.subplot(1, 2, 2)
    plt.bar(range(len(PROCESSES_TO_TEST)), training_steps_ps)
    plt.xticks(range(len(PROCESSES_TO_TEST)), PROCESSES_TO_TEST)
    plt.xlabel("Processes")
    plt.ylabel("Training steps per second")
    plt.show()
    plt.close()

if __name__ == "__main__":
    main()