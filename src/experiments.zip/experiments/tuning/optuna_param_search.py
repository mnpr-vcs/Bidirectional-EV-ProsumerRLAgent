from typing import Any, Dict

import optuna
import gymnasium as gym
from optuna.pruners import MedianPruner
from optuna.samplers import TPESampler

from stable_baselines3 import PPO, SAC, TD3
from stable_baselines3.common.callbacks import EvalCallback
from stable_baselines3.common.monitor import Monitor
import torch
import torch.nn as nn

import hems_env
from components.battery import HEMSBattery
from utils.configs import (
    data_config, env_config, battery_config
)
from utils.processing.etl import (
    get_dataset_as_dataframe, merge_transform_dataframes
)
from utils.event_logger import logger

# observation dataset preparation :
# ---------------------------------------------------
prosumers = get_dataset_as_dataframe(
    directory_path=data_config["prosumer_dir"],
    index_col=data_config["index_col"],
    usecols=data_config["prosumer_usecols"],
    index_freq=data_config["index_freq"],
)
assert len(prosumers) == 2

pricing = get_dataset_as_dataframe(
    directory_path=data_config["pricing_dir"],
    index_col=data_config["index_col"],
    usecols=data_config["pricing_usecols"],
    index_freq=data_config["index_freq"],
)
assert len(pricing) == 1

power_household, power_pv, auction_price, soc = merge_transform_dataframes(
    prosumers, pricing, data_config["index_col"], data_config["index_freq"]
)
assert len(power_household) == len(power_pv) == len(soc) == len(auction_price) == 35041 * 2
initial_soc = soc.iloc[0]
logger.info(">> dataset loaded")

# environments (Monitor)
# --------------------------------------------------
battery = HEMSBattery(
    initial_soc=initial_soc, max_capacity=battery_config["max_capacity"]
)
env = Monitor(
    gym.make(
        "hems_env/HouseholdEnv-v0",
        power_household=power_household,
        power_pv=power_pv,
        observation_window=env_config["observation_window_train"],
        auction_price=auction_price,
        battery=battery,
    )
)
logger.info(">> environment initialized")


# Parameters
# --------------------------------------------------
NUM_TRIALS = 50
NUM_STARTUP_TRIALS = 50
NUM_EVALUATIONS = 2
NUM_TIMESTEPS = env_config["observation_window_train"]
EVAL_FREQ = int(NUM_TIMESTEPS / NUM_EVALUATIONS)
NUM_EVAL_EPISODES = 2
POLICY_CONFIG = {
    "policy": "MlpPolicy",
}
TIMEOUT = None


# PPO sampler
# --------------------------------------------------
def sample_ppo_params(trial: optuna.Trial) -> Dict[str, Any]:
    """Sampler for PPO hyperparameters."""
    logger.info(">> sampling ppo params")
    learning_rate = trial.suggest_float("lr", 1e-6, 1e-2, log=True)
    # gamma = 1.0 - trial.suggest_float("gamma", 0.0001, 0.1, log=True)
    # gae_lambda = 1.0 - trial.suggest_float("gae_lambda", 0.001, 0.2, log=True)
    # clip_range = trial.suggest_float("clip_range", 0.001, 0.5, log=True)
    # n_steps = 2 ** trial.suggest_int("exponent_n_steps", 8, 13) # (256,8192)
    net_arch = trial.suggest_categorical("net_arch", ["tiny", "small", "medium", "wide"])
    if net_arch == "tiny":
        net_arch = {"pi": [64, 32], "vf": [64, 32]}
    elif net_arch == "small":
        net_arch = {"pi": [64, 64, 32], "vf": [64, 64, 32]}
    elif net_arch == "medium":
        net_arch = {"pi": [128, 128, 32], "vf": [128, 128, 32]}
    else:
        net_arch = {"pi": [256, 256, 32], "vf": [256, 256, 32]}

    # Display true values.
    # trial.set_user_attr("gamma_", gamma)
    # trial.set_user_attr("gae_lambda_", gae_lambda)
    # trial.set_user_attr("n_steps_", n_steps)

    return {
        # "n_steps": n_steps,
        # "gamma": gamma,
        # "gae_lambda": gae_lambda,
        "learning_rate": learning_rate,
        # "clip_range": clip_range,
        "policy_kwargs": {"net_arch": net_arch},
    }


# SAC sampler
# --------------------------------------------------
def sample_sac_params(trial: optuna.Trial) -> Dict[str, Any]:
    """Sampler for SAC hyperparameters."""
    logger.info(">> sampling sac params")
    learning_rate = trial.suggest_float("lr", 1e-6, 1e-2, log=True)
    # gamma = 1.0 - trial.suggest_float("gamma", 0.0001, 0.1, log=True)
    # tau = trial.suggest_float("tau", 0.001, 0.5, log=True)
    # buffer_size = 10 ** trial.suggest_int("exponent_buffer_size", 4, 6) 
    net_arch = trial.suggest_categorical("net_arch", ["tiny", "small", "medium", "wide"])
    if net_arch == "tiny":
        net_arch = {"pi": [128, 128], "qf": [128, 128]}
    elif net_arch == "small":
        net_arch = {"pi": [256, 128, 32], "qf": [256, 128, 32]}
    elif net_arch == "medium":
        net_arch = {"pi": [256, 256, 32], "qf": [256, 256, 32]}
    else:
        net_arch = {"pi": [512, 256, 32], "qf": [512, 256, 32]}

    # Display true values.
    # trial.set_user_attr("gamma_", gamma)
    # trial.set_user_attr("buffer_size_", buffer_size)

    return {
        # "buffer_size": buffer_size,
        # "gamma": gamma,
        "learning_rate": learning_rate,
        # "tau": tau,
        "policy_kwargs": {"net_arch": net_arch},
    }


# TD3 sampler
# --------------------------------------------------
def sample_td3_params(trial: optuna.Trial) -> Dict[str, Any]:
    """Sampler for TD3 hyperparameters."""
    logger.info(">> sampling td3 params")
    learning_rate = trial.suggest_float("lr", 1e-6, 1e-2, log=True)
    # gamma = 1.0 - trial.suggest_float("gamma", 0.0001, 0.1, log=True)
    # tau = trial.suggest_float("tau", 0.001, 0.5, log=True)
    # buffer_size = 10 ** trial.suggest_int("exponent_buffer_size", 4, 6) 
    net_arch = trial.suggest_categorical("net_arch", ["tiny", "small", "medium", "wide"])
    if net_arch == "tiny":
        net_arch = {"pi": [128, 128], "qf": [128, 128]}
    elif net_arch == "small":
        net_arch = {"pi": [256, 256, 32], "qf": [256, 256, 32]}
    elif net_arch == "medium":
        net_arch = {"pi": [400, 300, 32], "qf": [400, 300, 32]}
    else:
        net_arch = {"pi": [512, 256, 32], "qf": [512, 256, 32]}

    # Display true values.
    # trial.set_user_attr("gamma_", gamma)
    # trial.set_user_attr("buffer_size_", buffer_size)

    return {
        # "buffer_size": buffer_size,
        # "gamma": gamma,
        "learning_rate":  learning_rate,
        # "tau": tau,
        "policy_kwargs": {"net_arch": net_arch},
    }


# Callback
# --------------------------------------------------
class TrialEvalCallback(EvalCallback):
    def __init__(
        self,
        eval_env: gym.Env,
        trial: optuna.Trial,
        n_eval_episodes: int = NUM_EVAL_EPISODES,
        eval_freq: int = EVAL_FREQ,
        deterministic: bool = False,
        verbose: int = 1,
    ):
        super().__init__(
            eval_env=eval_env,
            n_eval_episodes=n_eval_episodes,
            eval_freq=eval_freq,
            deterministic=deterministic,
            verbose=verbose,
        )
        self.trial = trial
        self.eval_idx = 0
        self.is_pruned = False

    def _on_step(self) -> bool:
        if self.eval_freq > 0 and self.n_calls % self.eval_freq == 0:
            super()._on_step()
            self.eval_idx += 1
            self.trial.report(self.last_mean_reward, self.eval_idx)
            # Prune trial if need.
            if self.trial.should_prune():
                self.is_pruned = True
                return False
        return True


# PPO Objective
# --------------------------------------------------
def objective_ppo(trial: optuna.Trial) -> float:

    kwargs = sample_ppo_params(trial)
    kwargs.update(POLICY_CONFIG.copy())
    kwargs.update(env=env)
    model = PPO(**kwargs)
    eval_callback = TrialEvalCallback(
        eval_env=env,
        trial=trial,
        n_eval_episodes=NUM_EVAL_EPISODES,
        eval_freq=EVAL_FREQ,
        deterministic=True,
    )
    nan_encountered = False
    try:
        model.learn(NUM_TIMESTEPS, callback=eval_callback)
    except AssertionError as e:
        # Sometimes, random hyperparams can generate NaN.
        print(e)
        nan_encountered = True
    finally:
        # Free memory.
        model.env.close()
        env.close()
    if eval_callback.is_pruned:
        raise optuna.exceptions.TrialPruned()
    if not nan_encountered:
        return eval_callback.last_mean_reward
    else:
        return float("nan")  # trial failed


# SAC Objective
# --------------------------------------------------
def objective_sac(trial: optuna.Trial) -> float:

    kwargs = sample_sac_params(trial)
    kwargs.update(POLICY_CONFIG.copy())
    kwargs.update(env=env)
    model = SAC(**kwargs)
    eval_callback = TrialEvalCallback(
        eval_env=env,
        trial=trial,
        n_eval_episodes=NUM_EVAL_EPISODES,
        eval_freq=EVAL_FREQ,
        deterministic=True,
    )
    nan_encountered = False
    try:
        model.learn(NUM_TIMESTEPS, callback=eval_callback)
    except AssertionError as e:
        # Sometimes, random hyperparams can generate NaN.
        print(e)
        nan_encountered = True
    finally:
        # Free memory.
        model.env.close()
        env.close()

    if eval_callback.is_pruned:
        raise optuna.exceptions.TrialPruned()
    if not nan_encountered:
        return eval_callback.last_mean_reward
    else:
        return float("nan")  # trial failed


# TD3 Objective
# --------------------------------------------------
def objective_td3(trial: optuna.Trial) -> float:

    kwargs = sample_td3_params(trial)
    kwargs.update(POLICY_CONFIG.copy())
    kwargs.update(env=env)
    model = TD3(**kwargs)
    eval_callback = TrialEvalCallback(
        eval_env=env,
        trial=trial,
        n_eval_episodes=NUM_EVAL_EPISODES,
        eval_freq=EVAL_FREQ,
        deterministic=True,
    )
    nan_encountered = False
    try:
        model.learn(NUM_TIMESTEPS, callback=eval_callback)
    except AssertionError as e:
        # Sometimes, random hyperparams can generate NaN.
        print(e)
        nan_encountered = True
    finally:
        # Free memory.
        model.env.close()
        env.close()

    if eval_callback.is_pruned:
        raise optuna.exceptions.TrialPruned()
    if not nan_encountered:
        return eval_callback.last_mean_reward
    else:
        return float("nan")  # trial failed


if __name__ == "__main__":

    torch.set_num_threads(1)

    sampler = TPESampler(n_startup_trials=NUM_STARTUP_TRIALS)
    pruner = MedianPruner(
        n_startup_trials=NUM_STARTUP_TRIALS, n_warmup_steps=NUM_EVALUATIONS // 3
    )

    logger.info(">> study for ppo init")
    study_ppo = optuna.create_study(
        storage="sqlite:///db.sqlite3",
        sampler=sampler,
        pruner=pruner,
        direction="maximize",
        study_name="ppo",
        load_if_exists=True,
    )
    logger.info(">> study for sac init")
    study_sac = optuna.create_study(
        storage="sqlite:///db.sqlite3",
        sampler=sampler,
        pruner=pruner,
        direction="maximize",
        study_name="sac",
        load_if_exists=True,
    )
    logger.info(">> study for td3 init")
    study_td3 = optuna.create_study(
        storage="sqlite:///db.sqlite3",
        sampler=sampler,
        pruner=pruner,
        direction="maximize",
        study_name="td3",
        load_if_exists=True,
    )

    try:
        study_ppo.optimize(objective_ppo, n_trials=NUM_TRIALS, timeout=TIMEOUT)
        study_sac.optimize(objective_sac, n_trials=NUM_TRIALS, timeout=TIMEOUT)
        study_td3.optimize(objective_td3, n_trials=NUM_TRIALS, timeout=TIMEOUT)
    except KeyboardInterrupt:
        pass

    logger.info(f"Number of ppo finished trials:{len(study_ppo.trials)}")
    logger.info(f"Number of sac finished trials:{len(study_sac.trials)}")
    logger.info(f"Number of td3 finished trials:{len(study_td3.trials)}")

    logger.info("-----------------------*--------------------------")
    logger.info("----------------------PPO-------------------------")
    logger.info("Best trial:")
    trial_ppo = study_ppo.best_trial
    logger.info(f"Value: {trial_ppo.value}")
    logger.info("Params: ")
    for key, value in trial_ppo.params.items():
        logger.info(f"{key}: {value}")
    logger.info(f"User attrs: {trial_ppo.user_attrs}")
    for key, value in trial_ppo.user_attrs.items():
        logger.info(f"{key}: {value}")

    logger.info("----------------------SAC-------------------------")
    logger.info("Best trial:")
    trial_sac = study_sac.best_trial
    logger.info(f"Value: {trial_sac.value}")
    logger.info("Params: ")
    for key, value in trial_sac.params.items():
        logger.info(f"{key}: {value}")
    logger.info(f"User attrs: {trial_sac.user_attrs}")
    for key, value in trial_sac.user_attrs.items():
        logger.info(f"{key}: {value}")

    logger.info("----------------------TD3-------------------------")
    logger.info("Best trial:")
    trial_td3 = study_td3.best_trial
    logger.info(f"Value: {trial_td3.value}")
    logger.info("Params: ")
    for key, value in trial_td3.params.items():
        logger.info(f"{key}: {value}")
    logger.info(f"User attrs: {trial_td3.user_attrs}")
    for key, value in trial_td3.user_attrs.items():
        logger.info(f"{key}: {value}")
