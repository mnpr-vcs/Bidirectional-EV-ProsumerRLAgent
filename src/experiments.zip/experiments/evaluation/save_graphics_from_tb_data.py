"""
# runs from `cd src/<here>`
# makes use of tensorboard data saved as csv and plots a comparison graphic in png.
"""
import os
import pandas as pd 
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np

import utils.graphics
from utils.configs import results_paths

df_ppo = pd.read_csv("./res_acc/results_with_soc_retain_0.25/tensorboard/ppo_train_07-26_21-15.csv")
df_sac = pd.read_csv("./res_acc/results_with_soc_retain_0.25/tensorboard/sac_train_07-26_21-04.csv")
df_td3 = pd.read_csv("./res_acc/results_with_soc_retain_0.25/tensorboard/td3_train_07-26_21-04.csv")
df_ppo_retrain = pd.read_csv("./res_acc/results_with_soc_retain_0.25/tensorboard/ppo_retrain_07-26_23-25.csv")

dir_to_save_graphics = "./res_acc/results_with_soc_retain_0.25/tensorboard/"


# subplot and fill graphics
def plot_ppo_sac_td3(df_ppo, df_sac, df_td3, dir_to_save_graphics, figure_name):
    fig, ax = plt.subplots(sharex=True, sharey=True)
    ax.plot(df_ppo["Step"], df_ppo["Value"], label="PPO", color="blue")
    ax.fill_between(df_ppo["Step"], df_ppo["Value"], 0, color="blue", alpha=0.1)

    ax.plot(df_sac["Step"], df_sac["Value"], label="SAC", color="green")
    ax.fill_between(df_sac["Step"], df_sac["Value"], 0, color="green", alpha=0.1)

    ax.plot(df_td3["Step"], df_td3["Value"], label="TD3", color="red")
    ax.fill_between(df_td3["Step"], df_td3["Value"], 0, color="red", alpha=0.1)

    ax.set_ylabel("Percieved Cost Saved (EUR)")
    ax.set_xlabel("Num. of Train/Eval. Episodes")
    ax.legend()

    plt.suptitle("PPO vs. SAC vs. TD3 : Comparison based on cost minimized by RL agents")
    plt.savefig(os.path.join(dir_to_save_graphics, figure_name))
    plt.close(fig)

def plot_train_retrain(df_ppo, df_ppo_retrain, dir_to_save_graphics, figure_name):

    train_end_step = int(df_ppo["Step"].iloc[len(df_ppo) - 1])
    df_ppo_retrain["Step"] = df_ppo_retrain["Step"] + train_end_step

    fig, ax = plt.subplots()
    ax.plot(df_ppo["Step"], df_ppo["Value"], label="PPO", color="blue")
    ax.fill_between(df_ppo["Step"], df_ppo["Value"], 0, color="blue", alpha=0.1)

    ax.plot(df_ppo_retrain["Step"], df_ppo_retrain["Value"], label="PPO retrained", color="green")
    ax.fill_between(df_ppo_retrain["Step"], df_ppo_retrain["Value"], 0, color="green", alpha=0.1)

    ax.set_ylabel("Percieved Cost Saved (EUR)")
    ax.set_xlabel("Num. of Train/Eval. Episodes")
    ax.legend()

    plt.savefig(os.path.join(dir_to_save_graphics, figure_name))
    plt.close(fig)


plot_ppo_sac_td3(
    df_ppo,
    df_sac, 
    df_td3,
    dir_to_save_graphics, 
    figure_name="comparison_ppo_sac_td3.png"
)

plot_train_retrain(
    df_ppo,
    df_ppo_retrain,
    dir_to_save_graphics, 
    figure_name="concat_ppo_retrain.png"
)
