import numpy as np
from stable_baselines3.common.base_class import BaseAlgorithm


def evaluate_agent(
    model: BaseAlgorithm, num_episodes: int, deterministic: bool = False
):
    """
    Evaluating the trained agent
    Args:
        model: The trained model
        num_episodes: Number of episodes to evaluate
        deterministic: Whether the agent should be deterministic
    Returns:
        The mean cumulative reward
    """
    vec_env = model.get_env()
    obs = vec_env.reset()
    cumulative_rewards = []
    for _ in range(num_episodes):
        episode_reward = 0
        done = False
        while not done:
            action, _states = model.predict(obs, deterministic=deterministic)
            obs, reward, done, info = vec_env.step(action)
            episode_reward += reward
        cumulative_rewards.append(episode_reward)
    mean_cumulative_reward = np.mean(cumulative_rewards)
    logger.info(f"Episodes {num_episodes}, Rwd mu: {mean_cumulative_reward}")

    return mean_cumulative_reward
