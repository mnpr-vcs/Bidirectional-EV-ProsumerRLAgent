"""
# runs from `cd src/results/<here>`
"""
import os
import pandas as pd


def get_avg_cost(dir_to_read_csv):
    
    df = pd.read_csv(dir_to_read_csv)
    avg_cost = df["cost"].sum()
    return avg_cost


def save_avg_cost(dir_to_save_csv, action="test"):
    avg_cost_ppo = get_avg_cost(
        dir_to_read_csv=f"./stats/ppo/{action}/step_stats_episode4.csv"
    )
    avg_cost_sac = get_avg_cost(
        dir_to_read_csv=f"./stats/sac/{action}/step_stats_episode4.csv"
    )
    avg_cost_td3 = get_avg_cost(
        dir_to_read_csv=f"./stats/td3/{action}/step_stats_episode4.csv"
    )
    avg_cost_rbc = get_avg_cost(
        dir_to_read_csv=f"./stats/rbc/step_stats.csv"
    )

    df = pd.DataFrame(
        {
            "ppo": [avg_cost_ppo],
            "sac": [avg_cost_sac],
            "td3": [avg_cost_td3],
            "rbc": [avg_cost_rbc]
        },
    )
    df.to_csv(
        os.path.join(dir_to_save_csv, f"avg_cost_{action}.csv"),
        index=False
    )

if __name__ == "__main__":
    save_avg_cost(dir_to_save_csv="./stats/", action="init")
    save_avg_cost(dir_to_save_csv="./stats/", action="test")
    print("done !!")